﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace class_library
{
    public class Episode
    {
        private int viewers { get; set; }
        private double reviewSum { get; set; }
        private double highestReview { get; set; }

        public Episode() 
        { 
            viewers = 0;
            reviewSum = 0;
            highestReview = 0;
        }

        public Episode(int viewers, double reviewSum, double highestReview)
        {
            this.viewers = viewers;
            this.reviewSum = reviewSum;
            this.highestReview = highestReview;
        }

        public void AddView(double rating)
        {
            viewers++;
            if(rating > highestReview)
            {
                highestReview = rating;
            }

            reviewSum += highestReview;
        }

        public double GetMaxScore()
        {
            return highestReview;
        }

        public double GetAverageScore()
        {
            return reviewSum / viewers;
        }

        public int GetViewerCount()
        {
            return viewers;
        }
    }
}
