﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_library
{
    public class Episode
    {
        private int NumberOfViewers { get; set; }
        private double EpisodeSumScore { get; set; }
        private double HighestScore { get; set; }

        //konstruktor bez parametara - daješ neke default vrijednosti
        public Episode()
        {
            NumberOfViewers = 0;
            EpisodeSumScore = 0;
            HighestScore = 0;

        }

        //konstruktor s parametrima --> prima broj gledatelja, ocjenu i najveću ocjenu 
        //pa povežeš s poljima koja su gore definirana u klasi
        public Episode(int noOfViewers, double epScore, double hiScore)
        {
            NumberOfViewers = noOfViewers;
            EpisodeSumScore = epScore;
            HighestScore = hiScore;
        }

        //metoda koja samo vrati najveću ocjenu
        public double GetMaxScore()
        {
            return HighestScore;
        }

        public double GetAverageScore()
        {
            return EpisodeSumScore / NumberOfViewers;
        }

        public int GetViewerCount()
        {
            return NumberOfViewers;
        }
        //dodavanje pregleda --> mislim da ti je ovo najlakše u ovom slučaju
        //nema potrebe za listama i slično... pratiš ukupan broj viewera u običnoj int varijabli i povećavaš
        //za jedan kad se doda novi view
        //usporediš poslani score s najvećim trenutnim i ako je "novi" veći, onda njega postaviš kao najveći

        public void AddView(double score)
        {
            NumberOfViewers++;
            if (score > HighestScore)
            {
                HighestScore = score;
            }

            EpisodeSumScore += score;
        }
    }
}
